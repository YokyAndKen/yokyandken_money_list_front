<template>
  <div style="color: red;">count</div>
  <!-- echarts 进行数据统计 -->
</template>